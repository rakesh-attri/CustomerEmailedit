package com.sarvika.customerupdate;

public class Constants {

	public static final String DATE_FORMATE1 = "yyyy-MM-dd";
	public static final String DATE_FORMATE2 = "yyyy-MM-dd HH:mm:ss";

	public static boolean isProduction = false;
	
	// ShopStar
	public static final String USER_NAME = isProduction == true ? "sarvika_bot_prod" : "sarvika_bot"; //sarvika_bot //dkhandal
	public static final String USER_PASS = isProduction == true ? "halo12345" : "halo12345"; //halo12345  //deepak12345

}
