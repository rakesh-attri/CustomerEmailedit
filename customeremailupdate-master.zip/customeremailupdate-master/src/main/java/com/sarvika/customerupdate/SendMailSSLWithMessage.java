package com.sarvika.customerupdate;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang3.StringUtils;

public class SendMailSSLWithMessage {
	
	// Properties
	private static final String MAIL_SMTP_HOST = "smtp.gmail.com";
	private static final String MAIL_SMTP_SOCKET_FACTORY_PORT = "465";//"465"; //587
	private static final String MAIL_SMTP_AUTH_TRUE = "true";
	private static final String MAIL_SMTP_PORT = "465";//"465"; //587

	//Authenticator
	private static final String AUTHENTICATOR_EMAIL = "devprogramdks@gmail.com"; //"$guser"; //"devprogramdks@gmail.com"; //"guser@gmail.com"; //"devprogramdks@gmail.com"
	private static final String AUTHENTICATOR_PWD =  "d@@pak123"; //"$gpass"; //"d@@pak123"; //"gpass"; //"d@@pak123"
	
	// Set the from address
	private static final String FROM_EMAIL = "devprogramdks@gmail.com"; //"$guser";//"devprogramdks@gmail.com"; //"guser@gmail.com";
	
	// Set the recipient address
	private static final String RECIPIENT_EMAIL = "deepak.khandal@sarvika.com";//,rsharma@sarvika.com"; //rsharma@sarvika.com, apoorva.joshi@sarvika.com
	
	// Add the subject link
	private static final String SUBJECT_EMAIL = "Sprint to T-mobile " + Util.getLocalDate(Constants.DATE_FORMATE2) + " (Run by: " + Constants.USER_NAME + " )";
	
	// Set the body of email
	private static String BODY_EMAIL = "This e-mail regarding Sprint to T-mobile status";

	public static void sendEmailWithMessage(String emailMessage) {
		
		if(!StringUtils.isEmpty(emailMessage)){
			BODY_EMAIL = emailMessage;
		}
		
		// Create object of Property file
		Properties props = new Properties();

		// this will set host of server- you can change based on your requirement 
		props.put("mail.smtp.host", MAIL_SMTP_HOST);

		// set the port of socket factory 
		props.put("mail.smtp.socketFactory.port", MAIL_SMTP_SOCKET_FACTORY_PORT);

		// set socket factory
		props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");

		// set the authentication to true
		props.put("mail.smtp.auth", MAIL_SMTP_AUTH_TRUE);

		// set the port of SMTP server
		props.put("mail.smtp.port", MAIL_SMTP_PORT);
		
//		props.put("mail.smtp.ssl.enable", true);
		
		if(StringUtils.isEmpty(AUTHENTICATOR_EMAIL) || StringUtils.isBlank(AUTHENTICATOR_EMAIL)) {
			System.out.println("===== AUTHENTICATOR_EMAIL not set ===== " + AUTHENTICATOR_EMAIL);
			return;
		}else {
//			System.out.println("===== AUTHENTICATOR_EMAIL received ===== " + AUTHENTICATOR_EMAIL); // testing purpose only to see getting environment variable or not
		}
		if(StringUtils.isEmpty(AUTHENTICATOR_PWD) || StringUtils.isBlank(AUTHENTICATOR_PWD)) {
			System.out.println("===== AUTHENTICATOR_PWD not set ===== " + AUTHENTICATOR_PWD);
			return;
		}else {
//			System.out.println("===== AUTHENTICATOR_PWD received ===== " + AUTHENTICATOR_PWD); // testing purpose only to see getting environment variable or not
		}

		Session session = null;
		try {
			// This will handle the complete authentication
			session = Session.getDefaultInstance(props,

					new javax.mail.Authenticator() {

						protected PasswordAuthentication getPasswordAuthentication() {

						return new PasswordAuthentication(AUTHENTICATOR_EMAIL, AUTHENTICATOR_PWD);

						}

					});
		} catch (Exception e) {
			System.out.println("===== Authentication Failed =====" + e.getLocalizedMessage());
			e.printStackTrace();
		}


		try {

			// Create object of MimeMessage class
			Message message = new MimeMessage(session);

			try {
				// Set the from address
				message.setFrom(new InternetAddress(FROM_EMAIL, "Sprint to T-mobile "));
		    } catch (UnsupportedEncodingException e) {
		        e.printStackTrace();
		    }
			

			// Set the recipient address
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(RECIPIENT_EMAIL));
            
            // Add the subject link
			message.setSubject(SUBJECT_EMAIL);

			// Create object to add multimedia type content
			BodyPart messageBodyPart1 = new MimeBodyPart();

			// Set the body of email
			messageBodyPart1.setText(BODY_EMAIL);

//			// Create another object to add another content
//			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
//
//			// Create data source and pass the filename
//			DataSource source = new FileDataSource(screenshotFileWithPath);// Mention the file which you want to send
//
//			// set the handler
//			messageBodyPart2.setDataHandler(new DataHandler(source));
//
//			// set the file
//			messageBodyPart2.setFileName(screenshotFileName);
//
//			// Create object of MimeMultipart class
			Multipart multipart = new MimeMultipart();
//
//			// add body part 1
//			multipart.addBodyPart(messageBodyPart2);
//
//			// add body part 2
			multipart.addBodyPart(messageBodyPart1);
//
//			// set the content
			message.setContent(multipart);

			// finally send the email
			Transport.send(message);

			System.out.println("=====Email Sent Successfully=====");

		} catch (MessagingException e) {

			System.out.println("=====Email Failed due to =====" + e.getLocalizedMessage());
			e.printStackTrace();
//			throw new RuntimeException(e);

		}

	}

}