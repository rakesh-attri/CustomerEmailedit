package com.sarvika.customerupdate;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class Util {

	/*
	 * Time Zone dependent to getLocalDate
	 */
	  public static String getLocalDate(String format){
		  	Date date = new Date();
//		  	System.out.println("Default Server Date Time: "+ date.toString());
//		  	String format = "yyyy-MM-dd";
		  	String timeZone = "IST"; // PST // GMT // IST // UTC
		  	// create SimpleDateFormat object with input format
		 	SimpleDateFormat sdf = new SimpleDateFormat(format);
		 	// set timezone to SimpleDateFormat
		 	sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		 	String ldtString = sdf.format(date);
//		 	System.out.println("Local Date Time in " + timeZone +  " : " + ldtString);
		 	return ldtString;
	  }

	  
}
