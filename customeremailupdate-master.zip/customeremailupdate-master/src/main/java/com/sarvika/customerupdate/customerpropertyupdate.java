package com.sarvika.customerupdate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class customerpropertyupdate {

	// variable initialization
	// WebDriver object
	static WebDriver driver;
	// URLs
	static String loginUrl = "https://www.mylogocloud.com/login.admin";// "https://qa.mypromomall.com/preview/login.admin";
	static String loginUrlWithVid = "https://www.mylogocloud.com/loginvendor.admin?vid=20170512154";// "https://qa.mypromomall.com/preview/loginvendor.admin?vid=20200318517";
	static String storepropertiesUrl = "https://www.mylogocloud.com/storeproperties.admin?ppg=settings.admin&vid=";
	static String customers = "https://www.mylogocloud.com/viewcustomers.admin?ppg=managepeople.admin&vid=20170512154";// "https://qa.mypromomall.com/preview/viewcustomers.admin?ppg=managepeople.admin&vid=20200318517";
	static String dashboardUrl = "https://www.mylogocloud.com/listvendors.admin";

	// Text files of BufferedReader
	static BufferedReader objReaderVid = null;
	static BufferedReader objReaderEmailAddress = null;

	// Text files line content
	static String strCurrentLineVid = "";
	static String strCurrentLineEmail = "";
	// WebElements
	static String webElementUserName = "j_username";
	static String webElementPassword = "j_password";

	// Login Credentials
	static String userName = "dkhandal"; // "sarvika_bot";//"rsharma";
	static String userPassword = "deepak#12345"; // "halo12345"; //"halo123456";

	// required properties
	static String ADDRESS_NAME_ELEMENT = "//*[@id=\"address.address1\"]";
	static String CITY_ELEMENT = "//*[@id=\"address.city\"]";
	static String COUNTRY_NAME_ELEMENT = "//*[@id=\"country\"]";
	static String REGION_NAME_ELEMENT = "//*[@id=\"address.anotherprovince\"]";
	static String REGION_NAME_ELEMENT_COMBO = "//*[@id=\"Province\"]";
	static String ZIP_CODE_NAME_ELEMENT = "//*[@id=\"address.postal\"]";

	// Writing to file enable/disable
	static boolean writeToFile = true;

	// Files to write
	static String FAIL_EMAIL_UPDATE = "inputfiles/FailEmailUpdate.txt";
	static String ALLOWD_LOGIN_NAME_ALREADY_EXIST = "inputfiles/AllowedLoginName.txt";

	public void invokeBrowser() {
		try {

			System.setProperty("webdriver.chrome.driver", "chdriver/chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("enable-automation");
			options.addArguments("--disable-dev-shm-usage"); 
			options.addArguments("--aggressive-cache-discard"); 
			options.addArguments("--disable-cache"); 
			options.addArguments("--disable-application-cache"); 
			options.addArguments("--disable-offline-load-stale-cache"); 
			options.addArguments("--disk-cache-size=0");
			options.addArguments("--log-level=3"); 
			options.addArguments("--silent");
//			options.addArguments("--headless");
//			options.addArguments("--window-size=1920,1080");
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-extensions");
			options.addArguments("--dns-prefetch-disable");
			options.addArguments("--disable-gpu");
			options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
			driver = new ChromeDriver(options);
			driver.manage().deleteAllCookies();
//			driver.get("chrome://settings/clearBrowserData");
//			driver.findElement(By.xpath("//settings-ui")).sendKeys(Keys.ENTER);
//			driver.findElement(By.xpath("//*[@id=\"clearBrowsingDataConfirm\"]")).click();
			Thread.sleep(7000);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(60L, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(60L, TimeUnit.SECONDS);

		} catch (Exception e) {
			System.out.println("Exception occured in invokeBrowser");
			SendMailSSLWithMessage.sendEmailWithMessage(e.getLocalizedMessage() + "- invokeBrowser() execute ");
			e.printStackTrace();
		}
	}

	public void loginToSystem() {
		try {
			driver.get(loginUrl);
			driver.findElement(By.name(webElementUserName)).sendKeys(userName);
			driver.findElement(By.name(webElementPassword)).sendKeys(userPassword);
			driver.findElement(By.cssSelector(".btn")).click();
			Thread.sleep(2000);
			driver.findElement(By.cssSelector("#quick_search_box")).sendKeys("20170512154");
			driver.get(loginUrlWithVid);
		} catch (Exception e) {
			System.out.println("Exception occured in loginToSystem");
			SendMailSSLWithMessage
					.sendEmailWithMessage(e.getLocalizedMessage() + "- Exception occured in loginToSystem ");
			e.printStackTrace();
		}
	}

	public void initializeBufferedReaderFiles() {
		try {
			objReaderVid = new BufferedReader(new FileReader("inputfiles/username.txt"));
			objReaderEmailAddress = new BufferedReader(new FileReader("inputfiles/emailaddress.txt"));
		} catch (Exception e) {
			System.out.println("Exception occured while initialized input files");
			SendMailSSLWithMessage.sendEmailWithMessage(
					e.getLocalizedMessage() + "- Exception occured while initialized input files ");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {

		SendMailSSLWithMessage.sendEmailWithMessage("Sprint to T-Mobile program started");

		customerpropertyupdate customerpropertyupdate = new customerpropertyupdate();

		// Opening browser for checking test
		customerpropertyupdate.invokeBrowser();

		// Login to System with login credentials
		customerpropertyupdate.loginToSystem();

		// Initialization of bufferedReader files
		customerpropertyupdate.initializeBufferedReaderFiles();

		// this loop traverse all text files and update accordingly
		try {
			while ((strCurrentLineVid = objReaderVid.readLine()) != null
					&& (strCurrentLineEmail = objReaderEmailAddress.readLine()) != null) {

				driver.get(customers);
				Thread.sleep(5000);
				driver.findElement(By.id("searchvalue")).sendKeys(strCurrentLineVid);
				driver.findElement(By.id("manual_search")).click();

				System.out.println(strCurrentLineVid);
				Thread.sleep(3000);

//					WebElement element = driver.findElement(By.linkText(strCurrentLineVid));

				String text = getPageSourceCheck("No records found.");
				if (text.equalsIgnoreCase("No records found.")) {
					System.out.println("No records found." + strCurrentLineVid);
				} else {

					// driver.findElement(By.linkText(strCurrentLineVid)).click();
					driver.findElement(By.cssSelector("td > div > a")).click();

					driver.findElement(By.xpath("//input[@id='customer.email']")).clear();

					driver.findElement(By.xpath("//input[@id='customer.email']")).sendKeys(strCurrentLineEmail);

					driver.findElement(By.name("_apply")).click();
					driver.findElement(By.linkText("Customer Address")).click();

					WebElement mytable = driver.findElement(By.xpath("//*[@id=\"rows\"]/tbody"));
					// To locate rows of table.
					List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
					// To calculate no of rows In table.
					int rows_count = rows_table.size();
					// Loop will execute till the last row of table.
					for (int row = 1; row <= rows_count; row++) {
						System.out.println(row);
						Thread.sleep(3000);
						System.out.println(driver
								.findElement(By
										.cssSelector("#rows > tbody > tr:nth-child(" + row + ") > td:nth-child(2) > a"))
								.getText());
						driver.findElement(
								By.cssSelector("#rows > tbody > tr:nth-child(" + row + ") > td:nth-child(2) > a"))
								.click();
						Thread.sleep(5000);
						driver.findElement(By.xpath("//*[@id='address.email']")).clear();
						System.out.println(strCurrentLineEmail);
						driver.findElement(By.xpath("//*[@id='address.email']")).sendKeys(strCurrentLineEmail);
						Thread.sleep(3000);
						// *******************************************************************
						WebElement eleAddress = driver.findElement(By.xpath(ADDRESS_NAME_ELEMENT)); // find the text
																									// field
						WebElement eleCity = driver.findElement(By.xpath(CITY_ELEMENT)); // find the text field
						WebElement eleCountry = driver.findElement(By.xpath(COUNTRY_NAME_ELEMENT)); // find the text
																									// field
						WebElement eleZipcode = driver.findElement(By.xpath(ZIP_CODE_NAME_ELEMENT)); // find the text
																										// field
						WebElement eleRegion = null;
						WebElement eleRegionCombo = null;

						boolean isCountrySelected = false;
						if (eleCountry.getAttribute("value").equalsIgnoreCase("Please select...")) {
							isCountrySelected = false;

						} else {
							isCountrySelected = true;
						}

						if (!isCountrySelected) {
							eleRegion = driver.findElement(By.xpath(REGION_NAME_ELEMENT)); // find the text field
						} else {
							eleRegionCombo = driver.findElement(By.xpath(REGION_NAME_ELEMENT_COMBO)); // find the combo
						}

//				        	eleRegion = driver.findElement(By.xpath(REGION_NAME_ELEMENT)); //find the text field
//				            eleRegionCombo = driver.findElement(By.xpath(REGION_NAME_ELEMENT_COMBO)); //find the text field

						System.out.println("eleAddress= " + eleAddress.getAttribute("value"));
						System.out.println("eleCity= " + eleCity.getAttribute("value"));
						System.out.println("eleCountry= " + eleCountry.getAttribute("value"));
						if (eleRegion != null) {
							System.out.println("eleRegion= " + eleRegion.getAttribute("value"));
						}
						if (eleRegionCombo != null) {
							System.out.println("eleRegionCombo= " + eleRegionCombo.getAttribute("value"));
						}
						System.out.println("eleZipcode= " + eleZipcode.getAttribute("value"));

						if (eleAddress != null && !eleAddress.getAttribute("value").isEmpty() && eleCity != null
								&& !eleCity.getAttribute("value").isEmpty() && eleCountry != null
								&& !eleCountry.getAttribute("value").isEmpty() && eleZipcode != null
								&& !eleZipcode.getAttribute("value").isEmpty()
								&& ((eleRegion != null && !eleRegion.getAttribute("value").isEmpty())
										|| (eleRegionCombo != null
												&& !eleRegionCombo.getAttribute("value").isEmpty()))) {
							System.out.println("All are valid");
							if (eleRegionCombo.getAttribute("value").equalsIgnoreCase("0")) {
								// TODO: save email to text file
								System.out.println("\nWrite to file1 - " + strCurrentLineEmail);
								writeStoresResult(strCurrentLineEmail + "\n", FAIL_EMAIL_UPDATE); // writing to text
																									// file
								driver.findElement(By.name("_cancel")).click();
								Thread.sleep(5000);
								if (driver.findElement(By.name("_cancel")) != null) {
									Thread.sleep(3000);
									driver.findElement(By.name("_cancel")).click();
								}
							} else {
								Thread.sleep(5000);
								driver.findElement(By.name("_apply")).click();
								Thread.sleep(3000);
								driver.findElement(By.name("_ok")).click();

								System.out.println("-------------------------------------------------- ");
							}

						} else {
							System.out.println("All are not valid");
							// TODO: save email to text file
							System.out.println("\nWrite to file2 - " + strCurrentLineEmail);
							writeStoresResult(strCurrentLineEmail + "\n", FAIL_EMAIL_UPDATE); // writing to text file
							driver.findElement(By.name("_apply")).click();
							Thread.sleep(3000);
							driver.findElement(By.name("_cancel")).click();
							Thread.sleep(5000);
							if (driver.findElement(By.name("_cancel")) != null) {
								Thread.sleep(3000);
								driver.findElement(By.name("_cancel")).click();
							}

						}

//				        	if (eleAddress.getAttribute("value").isEmpty()) {
//				        	    //Do something if the text field is empty
//				        		
//				        		driver.findElement(By.name("_cancel")).click();
//				        	}
//				        	else {
//				        	    //then update the email
//					        	driver.findElement(By.name("_apply")).click();
//					        	Thread.sleep(3000);
//					        	driver.findElement(By.name("_ok")).click();
//					    		
//					    	 
//					    	    System.out.println("-------------------------------------------------- ");
//				        	}
					}

					try {
						WebDriverWait waitLogin = new WebDriverWait(driver, 180);
						waitLogin.until(ExpectedConditions.visibilityOfElementLocated(By.name("_ok")));
						Thread.sleep(8000);
						driver.findElement(By.name("_ok")).click();//// *[@id="mainpage"]/form/div[1]/span[2]/input[1]
						Thread.sleep(8000);
						driver.findElement(By.linkText("Customer Properties")).click();
						Thread.sleep(3000);
						driver.findElement(By.name("Add")).click();
						Select property = new Select(driver.findElement(By.id("selnames")));

						property.selectByVisibleText("allowed_login_name");
						Thread.sleep(2000);
						driver.findElement(By.xpath("//input[@id='textprovalue']")).clear();
						driver.findElement(By.id("textprovalue")).sendKeys("Yes");
						driver.findElement(By.name("Apply")).click();
						Thread.sleep(3000);
						driver.findElement(By.name("Ok")).click();

					} catch (Exception e) {
						System.out.println("required to bypass due to customer property 'allowed_login_name\' already exist. - " + strCurrentLineEmail + "\n" + e.getLocalizedMessage());
						writeStoresResult(strCurrentLineEmail + "\n", ALLOWD_LOGIN_NAME_ALREADY_EXIST);
						continue;
					}
					Thread.sleep(15000);
					driver.get(customers);
					Thread.sleep(5000);
				}

			}
		} catch (Exception e) {
			System.out.println("Exception Occurred");
			e.printStackTrace();
			SendMailSSLWithMessage.sendEmailWithMessage(e.getLocalizedMessage() + "\nwhile execute on " + strCurrentLineEmail);
		} finally {
			System.out.println("Done on Listed Store(s)");
			SendMailSSLWithMessage.sendEmailWithMessage("Sprint to T-Mobile program ended");
			if (objReaderVid != null)
				objReaderVid.close();
			if (objReaderEmailAddress != null)
				objReaderEmailAddress.close();
//			if(driver != null)
//				driver.close();
		}
	} // end of main function

//	public static WebElement isElementPresent(By by, String linkContext) {
////		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//	try {
//
//		System.out.println(linkContext + " for " + "Element Present in isElementPresent");
//		return driver.findElement(by);
//	} catch (NoSuchElementException e) {
//		System.out.println(
//				linkContext + " for " + "Element absent - Came into NoSuchElementException isElementPresent");
//		return null;
//	} catch (Exception e) {
//		System.out.println(linkContext + " for " + "Element absent - Came into Exception isElementPresent");
//		return null;
//	}

	public static String getPageSourceCheck(String str) {
		if (driver.getPageSource().contains(str)) {
			System.out.println("Text is present");
			return str;
		} else {
			System.out.println("Text is absent");
			return "";
		}
	}

	public static void writeStoresResult(String writeStatusStr, String filePathAndName) {

		if (writeToFile) { // if we want to write to result file or not

			File file = null;
			FileOutputStream fileOutputStream = null;
			try {
				file = new File(filePathAndName);
				fileOutputStream = new FileOutputStream(file, true);
				// check if file exists
				if (file.exists()) {
//					System.out.println("StoresResult.txt file exists.");
					// fetch bytes from data
					byte[] bs = writeStatusStr.getBytes();
					fileOutputStream.write(bs);
					fileOutputStream.flush();
					fileOutputStream.close();
					System.out.println("Writing into file successfully -" + " " + writeStatusStr);
				} else {
					System.out.println("\n" + filePathAndName + " file not exists creating new one.");
					file.createNewFile(); // create file if not exists
					// fetch bytes from data
					byte[] bs = writeStatusStr.getBytes();
					fileOutputStream.write(bs);
					fileOutputStream.flush();
					fileOutputStream.close();
					System.out.println("Writing into file successfully -" + " " + writeStatusStr);
				}

			} catch (IOException e) {
				System.out.println(filePathAndName + " file not found or error while writing to status.");
				e.printStackTrace();
			} finally {
				try {
					if (fileOutputStream != null) {
						fileOutputStream.close();
					}
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}

} // end of class function
