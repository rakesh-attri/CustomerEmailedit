# Things to remember
1.) @sprint.com into username.txt and @t-mobile.com into emailaddress</br>
2.) Email's those are having empty address written into "inputfiles/FailEmailUpdate"</br>
3.) Email's those having "allowed_login_name" already script will by pass them into "inputfiles/AllowedLoginNam"